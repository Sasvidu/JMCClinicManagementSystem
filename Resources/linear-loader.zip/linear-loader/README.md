# Linear Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/wowrakibul02/pen/ExOpPRa](https://codepen.io/wowrakibul02/pen/ExOpPRa).

